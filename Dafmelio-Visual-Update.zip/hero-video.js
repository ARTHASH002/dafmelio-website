// Decorative film: preserve the poster when motion, network or playback is limited.
(() => {
  const video = document.getElementById('hero-film');
  const control = document.getElementById('hero-video-toggle');
  if (!video || !control) return;
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  const compact = window.matchMedia('(max-width: 700px)');
  const connection = navigator.connection;
  const label = control.querySelector('[data-video-label]');
  let manuallyPaused = false;
  let resumeWhenVisible = false;
  let failed = false;
  const setState = playing => {
    control.dataset.state = playing ? 'playing' : 'paused';
    label.textContent = playing ? 'Pause video' : 'Play video';
    control.setAttribute('aria-label', playing ? 'Pause background video' : 'Play background video');
  };
  const shouldUsePoster = () => reduced.matches || compact.matches || connection?.saveData || /(^|-)2g$/.test(connection?.effectiveType || '');
  async function play() {
    if (reduced.matches || failed) return;
    if (!video.getAttribute('src')) {
      video.src = video.dataset.src;
      video.load();
    }
    video.muted = true;
    try { await video.play(); }
    catch { setState(false); }
  }
  video.addEventListener('playing', () => { video.classList.add('is-ready'); setState(true); });
  video.addEventListener('pause', () => setState(false));
  video.addEventListener('error', () => {
    failed = true;
    video.classList.remove('is-ready');
    control.hidden = true;
  });
  control.addEventListener('click', () => {
    if (video.paused) { manuallyPaused = false; play(); }
    else { manuallyPaused = true; video.pause(); }
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { resumeWhenVisible = !video.paused; video.pause(); }
    else if (resumeWhenVisible && !manuallyPaused && !shouldUsePoster()) play();
  });
  function applyPreference() {
    control.hidden = reduced.matches || failed;
    if (shouldUsePoster()) { video.pause(); video.classList.remove('is-ready'); setState(false); }
    else if (!manuallyPaused && !document.hidden) play();
  }
  reduced.addEventListener('change', applyPreference);
  compact.addEventListener('change', applyPreference);
  connection?.addEventListener?.('change', applyPreference);
  setState(false);
  control.hidden = reduced.matches;
  // The poster and text are painted before the optional video request starts.
  const start = () => window.setTimeout(applyPreference, 350);
  if (document.readyState === 'complete') start();
  else window.addEventListener('load', start, { once: true });
})();
