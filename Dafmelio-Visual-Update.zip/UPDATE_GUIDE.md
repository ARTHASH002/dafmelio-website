# Dafmelio visual update — 24 September 2026

This is an update-only package for the existing Dafmelio website. It is NOT a complete site and has NOT been deployed from this session.

## Changed existing files
- index.html: animated hero, service illustrations, benefit strip, three-step process, page and social metadata.
- software.html: 12 illustrated software categories, taglines, compact enquiry tiles for the existing 33 additional tools, page and social metadata.

## New files
- visual-upgrade.css
- hero-video.js
- assets/software-visuals.webp
- assets/dafmelio-hero.mp4
- UPDATE_GUIDE.md

The 11.8-second muted video is a lightweight animated montage of technology illustrations, not footage of Dafmelio's office. It has a pause/play control. Mobile devices, data-saver connections and reduced-motion users initially see a still image. Mobile users can choose Play; reduced-motion users retain the still image.

Software images are original conceptual illustrations, not official product screenshots or evidence of vendor partnerships. Plan availability and quotations remain subject to confirmation.

## Install on Windows
1. Back up C:\Users\Spica\public\DafmelioWebsite before copying files.
2. Download Dafmelio-Visual-Update.zip.
3. Extract its contents directly into C:\Users\Spica\public\DafmelioWebsite, replacing only the same-named files. The ZIP has no enclosing folder.
4. Do not replace your existing firebase-config.js, firebase.json, .firebaserc or firestore.rules. None are included in this update.
5. In PowerShell:

```powershell
cd "C:\Users\Spica\public\DafmelioWebsite"
npx.cmd --yes firebase-tools deploy --only hosting --project dafmelio-web-09434ac5
```

The explicit project flag targets only the new Dafmelio Website project. This command does not deploy Firestore rules, Authentication or other Firebase projects.

## Verify after deployment
- Open https://dafmelio-web-09434ac5.web.app and refresh with Ctrl+F5.
- Desktop: check hero playback and Pause/Play.
- Mobile: confirm readable layout and still-image fallback; tap Play if desired.
- Open software.html: confirm images, search, category filters and WhatsApp/email enquiry links.
- WhatsApp must open 8122330344; call links must use tel:+918122330344.
- Check existing client reviews remain visible and approval still works with your real Firebase configuration.
- Check https://dafmelio.com once Firebase shows the custom domain as connected.

## Verification performed
- Both edited pages: local asset/page links resolve; unique IDs; one H1; metadata and JSON-LD parse.
- All 12 primary software cards have images; 33 tool tiles retain enquiry links.
- Header, footer, contact dock and existing homepage review cards match the original archive.
- firebase-config.js, firestore.rules, reviews.js, admin-reviews.js, review.html, admin-reviews.html, site.js and styles.css are byte-for-byte unchanged.
- Hero JavaScript syntax checked. Mocked-DOM tests passed for play/pause, tab visibility, error fallback, mobile opt-in, reduced motion and data saver.
- MP4 validated: H.264, 1280x720, 11.79 seconds, no audio, approximately 1.14 MB.
- Browser screenshot, real-device playback and live Firebase tests were unavailable in this environment and still require the checks above. No ranking or AI-search inclusion is guaranteed by metadata updates.

## UI implementation note
UI UX Designer guidance informed hierarchy, original illustrative imagery, touch targets and motion accessibility. FLOWSTACK implementation was unavailable: no FLOWSTACK package/version or lockfile is installed in this static HTML project, and no exact-version owner guidance was resolved. No FLOWSTACK component APIs or styles are claimed. The explicit fallback is application-owned HTML/CSS/JavaScript; no framework migration or paid dependency was added.

## Rollback
Restore index.html and software.html from your backup and redeploy Hosting to the same explicit project. The new unused assets can safely remain until you choose to remove them.
